# Baseapp

## v2.4

 * Integration of bootstrap and refactoring minor style with it
 * Remove depedancy to openware/components and merge them
 * Support for CSRF (breaking change)
 * Password strength indicator
 * Integration of a Base Landing page
 * Integration of an API documentation for traders and bots
 * Finex integration
 
## v2.5

 * New wallet page mobile responsive
 * React upgrade
 * Unify configuration management from barong/peatio config api
 * Stop Loss order form
 * Rework login redux flow

## v3.0

Not defined
